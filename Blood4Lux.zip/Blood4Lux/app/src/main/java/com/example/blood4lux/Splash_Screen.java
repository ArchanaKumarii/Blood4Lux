package com.example.blood4lux;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

@SuppressWarnings("deprecation")
public class Splash_Screen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash__screen);
        Handler handler = new Handler();
        handler.postDelayed(() -> {
            startActivity(new Intent(Splash_Screen.this, LoginActivity.class));
                   finish();


        }, 2500);

    }
}