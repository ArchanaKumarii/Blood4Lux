package com.example.blood4lux;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class RegisterActivity extends AppCompatActivity {

    private EditText nameEt, communeEt, bloodGroupEt, passwordEt, mobileEt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        nameEt = findViewById(R.id.name);
        communeEt = findViewById(R.id.commune);
        bloodGroupEt = findViewById(R.id.blood_group);
        passwordEt = findViewById(R.id.password);
        mobileEt = findViewById(R.id.number);
        Button submitButton = findViewById(R.id.submit_button);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name, commune, blood_group, password, mobile;
                name = nameEt.getText().toString();
                commune = communeEt.getText().toString();
                blood_group = bloodGroupEt.getText().toString();
                password = passwordEt.getText().toString();
                mobile = mobileEt.getText().toString();
                if (isValid(name, commune, blood_group, password, mobile)) {
                    register(name, commune, blood_group, password, mobile);



    }
            })


    ;}}

    private boolean isValid(String name, String commune, String blood_group, String password, String mobile) {

    }
}

    private void register(final String name, final String commune, final String blood_group, final String password, final String mobile) {
    StringRequest
    }
    }
